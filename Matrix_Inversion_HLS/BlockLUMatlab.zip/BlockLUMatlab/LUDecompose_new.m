function [Linv,Uinv,P] = LUDecompose_new(A)
    [row,col] = size(A);
    P = eye(row,col);
    for k = 1:row
        A_temp = max( A(k:row,k) );
        [x,y] = find ( A(:,k)==A_temp );
        %disp( A );
        %disp( P );
        P([k x],:)=P([x k],:);    %  Pivoting 
        A([k x],:)=A([x k],:); % Swapping 
        %disp( A );
        %disp( P );
        for i = k+1: row
            A(i,k) = A(i,k) / A(k,k);
            for j = k+1: row
                A(i,j) = A(i,j) - A(i,k).*A(k,j);
            end    
        end
        
    end 
    disp( A );
    % Partitioning into L and U
    L = eye(row,col);
    Linv = eye(row,col);
    U = eye(row,col);
    for i = 1: row
        for j = 1:row 
            if ( i>j )
                L(i,j) = A(i,j);
            else
                U(i,j) = A(i,j);
            end     
        end         
    end
    L = [L, eye(row,row)];
    for i =1:row
        for k=(i+1) : (row)
            for a=(i+1) : (i+row)
                L(k,a) = L(k,a) - L(k,i)*L(i,a);
            end
            L(k,i) = 0;
        end
    end
    
    Linv = L(:, (row+1: 2*row));
    %Linv = -1 * L;
    U = [U, eye(row,row)];
    for i = 1: row 
        for j = (i+1) : (i+row) 
            U(i,j) = U(i,j)/ U(i,i);
        end
        U(i,i)=1;
        for k = 1:i-1
            for a = 0:row-1
                U(k, i + 1  + a) = U(k,i + 1 + a) - U(k,i) * U(i,i + 1 + a);
            end
            U(k,i) =0 ;
        end
    end        
    Uinv = U(:, (row+1: 2*row));
    
    %row
    %Uinv = inv(U);
    %disp(L);
    %disp(U);
end