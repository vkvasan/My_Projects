function [Xinv,P_whole] = BlockLUinversion( A, b ) 
    n = size(A,1);
    size_A = n;
    offset =0;
    count = 1;
    N = floor(n/b);
    Uinv = zeros( n, n );
    Linv = zeros( n, n );
    P_whole = zeros( n, n);
    L1inv = zeros( b , b ,N-1);
    U1inv = zeros( b , b,N-1 );
    P1 = zeros( b , b,N-1 );
    T = zeros( b , b,N-1 );
    while ( size_A >  b )
        M1 = A( ( 1+ offset ): (b + offset), ( 1+ offset ):(b + offset) );
        [L1inv(:,:,count), U1inv(:,:,count) , P1(:,:,count)] = LUDecompose_new(M1);  
        T(:,:,count) = U1inv(:,:,count) * L1inv(:,:,count) ;
        Sbar = A((b+1 + offset):n , ( 1+ offset ): (b + offset) ) * T(:,:,count);
        A((offset + b+1): n, (offset + 1): (offset + b) ) = Sbar;
        A((b+1 + offset):n , (b+1 + offset):n ) = A((b+1 + offset):n , (b+1 + offset):n )- Sbar * P1(:,:,count) * A(( 1+ offset ): (b + offset), (b+1 + offset):n );
        size_A = size_A - b;
        offset = offset + b;
        count = count +1;
    end
    Decompfinal = A( ( offset +1 ): n , ( offset +1 ):n );
    [L1invfinal, U1invfinal,Pfinal] = LUDecompose_new(Decompfinal);
    count = count -1 ;
    while ( size_A ~= n )
       if ( size_A <= b)
           S = Pfinal * A ((offset + 1): n , (offset-b+1): offset );
       else    
           S = P_whole( ( offset +1 ): n, ( offset +1 ): n ) * A ((offset + 1): n , (offset-b+1): offset );
       end
       %%%%%%%
       if ( size_A <= b )
           Linv((offset + 1):n, ( offset+1 ): n ) = L1invfinal;
       end
       %%%%%%%
       if ( size_A <= b )
           Linv( ( offset +1):n, (offset -b +1) :offset ) = -1 * L1invfinal * S;
       else
           Linv( ( offset +1):n, (offset -b +1) :offset ) = -1 * Linv( ( offset +1):n, (offset +1) :n ) * S;
       end
       %%%%%%%
       Linv( ( offset -b +1):offset, (offset -b +1) :offset ) = L1inv(:,:,count);
       %%%%%end of Linv assignment 
       %%%%%%%
       
       
       if ( size_A <= b )
           Uinv((offset + 1):n, ( offset+1 ): n ) = U1invfinal;
       end
       %%%%%%%
       if ( size_A <= b )
           Uinv( ( offset -b +1): offset , (offset +1) : n ) = -1 * T(:,:,count) * P1(:, :,count) * A( (offset -b + 1): offset, (offset + 1):n ) * U1invfinal ;
       else
           Uinv( ( offset -b +1): offset , (offset +1) : n ) = -1 * T(:,:,count) * P1(:, :,count) * A( (offset -b + 1): offset, (offset + 1):n ) * Uinv((offset + 1):n, ( offset+1 ): n ) ;
       end
       %%%%%%%
       Uinv( ( offset -b +1):offset, (offset -b +1) :offset ) = U1inv(:,:,count);
       %%%%%end of Uinv assignment 
       %%%%%%%
       P_whole( ( offset -b +1):offset, (offset -b +1) :offset ) = P1(:,:,count);
       if ( size_A <= b )
           P_whole((offset + 1):n, ( offset+1 ): n ) = Pfinal;
       end    
        size_A = size_A + b;
        offset = offset - b;
        count = count - 1;
    end
    Xinv = Uinv * Linv * P_whole ;
end

    
       
    
           
    
        
        
