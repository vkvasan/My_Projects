
#include<stdio.h>
#include <stdlib.h>  // rand(), srand()
#include <time.h>
int main()
{
FILE *fp;
fp = fopen("file.txt","wb+");
srand((unsigned)time(0));
//sprintf(p, "\\x%x", hex);
int arr[100];
/*
for (int i = 0 ; i < 100; i = i+1 )
{
    arr[i] = (int)(rand()%100);
    //arr[i] = i;
    printf("%d",arr[i]);
    putw(arr[i], fp);
}
*/
int i = 0;
while(i++ < 20)
{
  fprintf(fp, "%d\n", rand()%10000);
}


//fwrite(arr, 4, 100, fp);
fclose(fp);
return 0;

}
